const data = () => {
    const products=[{
        _id:"1",
        name:"Panadol",
        Category:"Medicine",
        Drugtype:"Fever",
        Drugname:"Paracetmol",
        image:"https://cdn.shopify.com/s/files/1/0088/4758/9476/products/02557_1800x1800.png?v=1663076477",
        ShopOwner:"Bismillah Medical Store",
        price:"100",
        Size:"250mg",
        Status:"Stocked"
        }
          ,
        {   _id:"646446",
        name:"NEXUM-CAP20MG2X7'S",
        Category:"Medicine",
        Drugtype:"Acidity",
       Drugname:"Esomeprazole",
        image:"https://cdn.shopify.com/s/files/1/0088/4758/9476/products/04369_54b3c98f-e23c-457f-8024-935ee3cc5ef1_1800x1800.jpg?v=1670930941",
        ShopOwner:"Bismillah Medical Store",
        price:"148.76",
        Size:"20mg"
      },
      {
          _id:"3",
          name:"Flagyl Tablets 400mg 20X10's",
          Category:"Medicine",
          Drugtype:"Acidity",
          Drugname:"Esomeprazole",
          image:"https://cdn.shopify.com/s/files/1/0088/4758/9476/products/06644_1800x1800.png?v=1653028687",
          ShopOwner:"Bismillah Medical Store",
          price:"24.20",
          Size:"400mg",
          Status:"Stock"
      
      },{
         _id:"8",
          name:"NEXUM-CAP20MG2X7'S",
          Category:"Medicine",
          Drugtype:"Acidity",
          Drugname:"Esomeprazole",
          image:"https://cdn.shopify.com/s/files/1/0088/4758/9476/products/04369_54b3c98f-e23c-457f-8024-935ee3cc5ef1_1800x1800.jpg?v=1670930941",
          ShopOwner:"Bismillah Medical Store",
          price:"148.76",
          Size:"20mg",
          Status:"Stock"
      
      },{
        _id:"12",
        name: "Lasoride Tablets 3X10's",
        price:"181.50" ,
        Category:"Hypertension",
        Status:"Stock",
        Drugname: "Furosemide, Amiloride",
        Size:"3x10's" ,
        Drugtype: "Hypertension",
        ShopOwner:"Bismillah Medical Store",
        image:"https://cdn.shopify.com/s/files/1/0088/4758/9476/products/03828_1_384x384.png?v=1664537385"
      },
      { _id:"11",
        name: "Ascard Tab 75 MG 3x10's",
        price:"23.04" ,
        Status:"Stock",
        Drugname: "Acetylsalicylic Acid",
        Size:"75 mg" ,
        Drugtype: "Stroke",
        image:"https://cdn.shopify.com/s/files/1/0088/4758/9476/products/05405_384x384.png?v=1644213220"
      },
      { 
        _id:"14",
        name: "Ascard Tab 75 MG 3x10's",
        price:"23.04" ,
        Status:"Stock",
        Drugname: "Acetylsalicylic Acid",
        Size:"75 mg" ,
        Drugtype: "Stroke",
        image:"https://cdn.shopify.com/s/files/1/0088/4758/9476/products/05405_384x384.png?v=1644213220"
      },
      {  _id:"13",
          name:"Exforge Tablets 5/80mg 28's",
          price:"727.08" ,
          Status:"Stock",
          Drugname: "Amlodipine, Valsartan",
          Size:"5/80mg" ,
          Drugtype: "Hypertension",
          image:"https://cdn.shopify.com/s/files/1/0088/4758/9476/products/06147_1_800x384.jpg?v=1596438845"
    
      }
       ]
    return ( {products });
}
 
export default data;