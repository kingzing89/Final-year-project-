import { Box, Flex, Heading, Text ,Container} from "@chakra-ui/react";

const Headea = () => {
    return ( 
        <div className="Header">
            
                <Box bg="gray.500"  w='100%'  pl={{base:"30%",md:'40%'}}>
                    <Text color='gray.50'>Welcome to Medical App</Text>

                </Box>
 

        </div>
     );}
 
export default Headea;